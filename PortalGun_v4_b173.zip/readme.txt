http://www.minecraftforum.net/viewtopic.php?f=1032&t=215961

Mod by iChun.