STEAMCRAFT IS (C) PROLOE 2011 AND IS NOT ENDORSED BY NOTCH IN ANY WAY. IT IS NOT TO BE REDESTRIBUTED WITHOUT THE PERMISSON OF THE CREATOR UNDER ANY CIRCUMSTANCES.

INSTALLATION (Windows):
Find your RUN, and type in "%appdata%" without the quotation marks. Find ".minecraft", then find "bin". Back up the "minecraft.jar" file somewhere (once the mod is installed, it is permanent unless you replace this file). Open minecraft.jar with WinRAR or some other program, and delete the folder named "META-INF". Then, copy all the files in the "Place in minecraft jar" folder into your minecraft.jar. Now, go back to your .minecraft folder, and copy the folder in the "Place in minecraft folder" folder there. Lastly, copy the .zip file in the "Place in mods folder" folder into the "mods" folder.

NOTE: Do not attempt to open any worlds generated with this mod after having uninstalled the mod. The mod contains new block and item data, and may cause things to break if you try to open it without the mod installed. I take no responsibility if the mod screws up your save game because of this.

PLEASE BE AWARE THAT THIS MOD IS UNFINISHED, AND IS STILL UNDER CONSTRUCTION. MANY FEATURES OF THIS MOD ARE PLACEHOLDERS, AND WILL BE CHANGED IN FUTURE UPDATES.