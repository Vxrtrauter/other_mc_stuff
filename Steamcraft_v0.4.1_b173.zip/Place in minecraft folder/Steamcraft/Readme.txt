Here you will find the configuration file for the Steamcraft mod. This is designed to allow you to alter any IDs and such that conflict with other mods. Any alterations you make of this file are done at your own discretion, and I am not responsible for you messing up your game because of it.

The config file is very sensitive, and the slightest change to one of the variable names will cause Minecraft to crash on startup. As such, I highly recommend you back up your config file before editing.

~Proloe