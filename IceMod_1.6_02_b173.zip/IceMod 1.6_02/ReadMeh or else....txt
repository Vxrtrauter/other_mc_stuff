+ 1 life.


Get Modloader from:
http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-recipe-book-updated/

AudioMod from:
http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-recipe-book-updated/

Shockah's super awesome API:
http://www.minecraftforum.net/topic/78064-173-shockahs-mods/


Install.


If you have problems installing the mod look at the instruction video on the main topic,
If problems persist please contact us in any form or fashion.

Thank you.

Credits:
JabJabJab - "Ice Lord" Founder / main coder / modeler / etc.
mike4560 - "Yeti Tamer" AI 
Caironater - "Cave Dweller" Tools / Geodes (soon) 


Have fun!