Inatall
-------
- Delete Meta-inf
- Install ModLoader
- Install audio mod
- run minecraft once it gets to main window you can close it
- Drag and drop all files in the bin folder into the minecraft.jar
- Drag and drop rescources folder into the .minecraft folder

